<?php
$host= "localhost";
$user= "root";
$pass= "";
$bd= "supermercado";
$conexion = mysqli_connect($host, $user, $pass, $bd);